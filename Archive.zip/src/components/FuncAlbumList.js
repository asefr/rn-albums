
import React from 'react';
import { Text, View } from 'react-native';

// Function component
const AlbumList = () => (
  <View>
    <Text>Album list....</Text>
  </View>
);

export default AlbumList;
